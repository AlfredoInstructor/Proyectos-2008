#include <iostream.h>
#include <stdlib.h>
#include <stdio.h>
int suma;
int prom;
int temp [30];
int i=0;
int cr;
int lleno;
int opc;
int main()
{
while(i=1)
{
cout<<"\n 1-Agregar una temperatura del mes pasado:";
cout<<"\n 2-Saber el promedio de temperaturas del mes pasado:";
cout<<"\n 3-Saber el promedio de la primera quincena:";
cout<<"\n 4-Saber el promedio de la segunda quincena:";
cout<<"\n 5-Salir del programa:";
cout<<"\n Ingrese una opcion";
cin>>opc;
switch (opc)
{
case 1: {
        cout<<"\n Ha elegido agregar una tempertura del mes pasado:";
           i=0;
           while (i<30)
           {
           cout<< " \n Ingrese la temperatura de un dia del mes pasado:";
           cin>>temp[i];
           i=i+1;
           }
           lleno=1;
        }
        break;
case 2: {
        if (lleno==1)
        {
        cout<<"\n Ha elegido saber el pormedio de las temperaturas del mes pasado";
            suma=0;
            cr=0;
            while (cr<30)
            {
            suma=suma + temp [cr];
            cr=cr+1;
            }
            prom=suma/30;
            cout<<"\n El promedio del mes pasado es:"<<prom;
         }
         else
         {
         cout<<"\n Error";
         }
        }
        break;
case 3: {
        if (lleno==1)
        {
        cout<<"\n Ha elegido saber el promedio de la primera quincena";
            suma=0;
            cr=0;
            while (cr<16)
            {
            suma=suma + temp [cr];
            cr=cr+1;
            }
            prom=suma/15;
            cout<<"\n El promedio de la primera quincena es:"<<prom;
            }
         else
         {
         cout<<"\n Error";
         }
        }
           break;
case 4: {
        if (lleno==1)
        {
        cout<<"\n Ha elegido saber el promedio de la segunda quiencena:"<<prom;
            i=15;
            cr=15;
            while (cr<30)
            {
            suma=suma + temp [cr];
            cr=cr+1;
            }
            prom=suma/15;
            cout<<"\n El promedio de la segunda quincena es:"<<prom;
        }
        else
        {
        cout<<"\n Error";
        }
        }
        break;
case 5: {
         return 0;
        }
        break;
        default:{
                 cout<<"\n Ha elegido una opci�n equivocada";
                 }
}
cout<<"\n Desea ingresar otra opci�n?(1-si/0-no)";
cin>>opc;
}
      system("PAUSE");
      return 0;
}
